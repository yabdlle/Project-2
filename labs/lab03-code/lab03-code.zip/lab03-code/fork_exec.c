#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        return 1;
    } else if (pid == 0) {
        execlp("cat", "cat", "sample.txt", NULL);
        return 1;
    } else {
        int status;
        wait(&status);
        printf("Child exited with status %d\n", WEXITSTATUS(status));
    }

    return 0;
}
